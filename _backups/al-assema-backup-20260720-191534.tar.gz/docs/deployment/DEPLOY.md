# دليل النشر — Al Assema (العاصمة)

المشروع جزئين منفصلين، كل واحد بيتنشر لوحده:

| الجزء | المسار | النوع | الاستضافة المقترحة |
| ----- | ------ | ----- | ------------------ |
| الواجهة (Frontend) | [`app/`](../../app/) | Vite SPA ثابت (static) | Vercel / Netlify / أي static host |
| الخدمة الخلفية (Backend) | [`api/`](../../api/) | Next.js API + Prisma | Vercel / أي Node host |
| قاعدة البيانات | — | Postgres | Supabase |
| تخزين الصور | — | Object storage | Supabase Storage |

> الترتيب مهم: **قاعدة البيانات → الباك إند → الـ migrations والأدمن → الـ buckets → الفرونت إند → الربط (CORS/دومين)**.

---

## 0. المتطلبات قبل ما تبدأ

- حساب [Supabase](https://supabase.com) (مجاني يكفي للبداية).
- حساب [Vercel](https://vercel.com) (أو أي بديل).
- الكود متعمله `push` على GitHub (أول commit اتعمل بالفعل — كل اللي ناقص هو ربط الـ remote والـ push).
- Node 22 لو هتشغّل أوامر محليًا.

```bash
# لو لسه مربطتش remote:
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```


---

## 1. قاعدة البيانات (Supabase)

1. اعمل مشروع جديد في Supabase.
2. لو الاستضافة **serverful** (VPS / عملية Node شغالة طول الوقت، زي قسم
   "بديل: استضافة على VPS" تحت): استخدم **Session pooler** (منفذ 5432) لكل
   من `DATABASE_URL` و`DIRECT_URL` بنفس القيمة. السبب: الاتصال الـ Direct
   (`db.[PROJECT-REF].supabase.co`) IPv6-only وأغلب الـ VPS مش بيوصلّه، والـ
   Session pooler بيدعم IPv4 وبيتصرف كاتصال مباشر تقريبًا (آمن لـ
   `prisma migrate`)، على عكس الـ Transaction pooler (6543) اللي بيكسر
   prepared statements.
   - من **Settings → Database → Session pooler** خد الـ host بالكامل
     (الصيغة: `aws-0-[region].pooler.supabase.com` — ممكن يكون `aws-1-` في
     بعض المشاريع، فالأضمن تنسخه من اللوحة مباشرة).
   - اليوزر هنا لازم يبقى `postgres.[PROJECT-REF]` (مش `postgres` بس).
3. لو الاستضافة **serverless** (Vercel functions): استخدم **Transaction
   pooler** (منفذ 6543) لـ `DATABASE_URL` والـ **Direct** (5432) لـ
   `DIRECT_URL`، وفعّل `directUrl` في
   [`api/prisma/schema.prisma`](../../api/prisma/schema.prisma).

---

## 2. نشر الباك إند (`api/` على Vercel)

1. في Vercel: **New Project** → اختار نفس الريبو.
2. **Root Directory = `api`** (مهم جدًا).
3. Vercel هيقرأ [`api/vercel.json`](../../api/vercel.json) اللي بيشغّل `prisma generate && next build`.
4. حط متغيرات البيئة (من [`api/.env.example`](../../api/.env.example)) في
   **Settings → Environment Variables**:

   | المتغير | القيمة |
   | ------- | ------ |
   | `DATABASE_URL` | رابط Supabase الـ pooled |
   | `DIRECT_URL` | رابط Supabase الـ direct |
   | `NEXT_PUBLIC_SUPABASE_URL` | رابط مشروع Supabase |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | الـ anon key |
   | `SUPABASE_SERVICE_ROLE_KEY` | الـ service-role key (سري) |
   | `JWT_SECRET` | سر عشوائي قوي — `openssl rand -base64 32` |
   | `JWT_TTL` | مثلاً `7d` |
   | `CORS_ALLOWED_ORIGINS` | دومين الفرونت إند (هتعرفه بعد خطوة 5) |
   | `API_KEY` | اختياري — لازم يطابق `VITE_API_KEY` |

5. اعمل Deploy، وتأكد إن `https://<api-domain>/api/health` بيرجّع OK.

> **ملاحظة Prisma 7:** الـ client بيتولّد وقت الـ build؛ مفيش حاجة إضافية.

---

## 3. تشغيل الـ Migrations وإنشاء أول أدمن

يتعملوا **مرة واحدة** بعد ما قاعدة البيانات تبقى جاهزة. شغّلهم محليًا والـ `.env`
فيه نفس بيانات الإنتاج، أو من جهازك مباشرة على Supabase:

```bash
cd api
npm ci

# 1) إنشاء الجداول
npx prisma migrate deploy

# 2) تعبئة الكتالوج (شركات + تصنيفات)
npm run seed

# 3) إنشاء أول أدمن للدخول على /admin
ADMIN_EMAIL="you@site.com" ADMIN_PASSWORD="<باسورد قوي>" npm run create-admin
# أو:
npm run create-admin -- --email you@site.com --password '<باسورد قوي>' --name 'Site Admin'
```

> `create-admin` **idempotent** — لو شغّلته تاني بنفس الإيميل بيحدّث الباسورد
> ويرقّي الحساب لـ ADMIN. السكربت مش بيحفظ أي بيانات في الكود.

---

## 4. إنشاء Storage buckets في Supabase

رفع الصور من لوحة الأدمن بيحتاج 4 buckets. من **Supabase → Storage** اعمل:

`logos` · `covers` · `gallery` · `projects`

كلهم **Public read** + الكتابة عن طريق الـ service-role key (الموجود في الباك إند).

---

## 5. نشر الفرونت إند (`app/` على Vercel)

1. **New Project** تاني على نفس الريبو، بس **Root Directory = `app`**.
2. Vercel هيقرأ [`app/vercel.json`](../../app/vercel.json) (build + الـ SPA rewrites).
3. حط متغيرات البيئة (من [`app/.env.example`](../../app/.env.example)):

   | المتغير | القيمة |
   | ------- | ------ |
   | `VITE_API_URL` | `https://<api-domain>/api` (بدون `/` في الآخر) |
   | `VITE_API_KEY` | اختياري — لازم يطابق `API_KEY` في الباك إند |

   > متغيرات Vite بتتحقن وقت الـ build، فلو غيّرتها لازم تعمل redeploy.
4. اعمل Deploy.

---

## 6. الربط النهائي (CORS + الدومين)

1. ارجع لمشروع الباك إند على Vercel، وحدّث `CORS_ALLOWED_ORIGINS` بدومين الفرونت
   إند (مثلاً `https://alassema.com`)، واعمل redeploy.
2. اربط الدومين المخصص لكل مشروع من **Settings → Domains** (HTTPS تلقائي).
3. جرّب:
   - الصفحة الرئيسية بتعرض الشركات (يعني الفرونت بيكلّم الـ API).
   - اعمل طلب خدمة → لازم يظهر في `/admin`.
   - سجّل دخول على `/admin` ببيانات الأدمن.

---

## 7. تحسينات الإنتاج (مهمة قبل ضغط حقيقي)

- [ ] **Rate limiting (مهم على Vercel / أي serverless):** الـ in-memory limiter
      بيتصفّر مع كل cold lambda، فعمليًا مفيش حماية على serverless/أكتر من نسخة.
      عشان كده **في الإنتاج التطبيق هيرفض يقلع** لو مفيش Redis مظبوط — حط
      `UPSTASH_REDIS_REST_URL` + `UPSTASH_REDIS_REST_TOKEN` (الكود بيتحوّل لـ Redis
      تلقائيًا وبيرجع لـ in-memory لو Redis وقع لحظيًا). لو شغّال **نسخة واحدة طول
      الوقت** (PM2 fork على VPS) والـ in-memory كفاية، حط `RATE_LIMIT_ALLOW_INMEMORY=1`
      صراحةً.
- [ ] **إيميلات الإشعارات (اختياري):** حط `RESEND_API_KEY` + `RESEND_FROM` (sender
      موثّق) علشان مزوّد الخدمة ياخد إيميل مع كل طلب جديد. من غيرها الطلبات بتتسجّل عادي.
- [ ] **CAPTCHA (اختياري):** حط `TURNSTILE_SECRET_KEY` (أو `RECAPTCHA_SECRET_KEY`)
      لتفعيل الحماية على فورمات الطلب/التقييم. **مهم:** تفعيله بيتطلّب إضافة الـ widget
      في الفرونت وإرسال الـ token، وإلا كل الطلبات هتترفض.
- [ ] **مراقبة الأخطاء (اختياري):** حط `SENTRY_DSN` علشان الأخطاء (500) تتبعت لـ Sentry.
- [ ] **الجاهزية (Readiness):** خلي الـ load balancer / monitor يضرب
      `GET /api/ready` (بيتأكد إن قاعدة البيانات شغالة، بيرجّع 503 لو وقعت) بدل
      `/api/health` (liveness بس). الاتنين مُعفيين من بوابة الـ API key.
- [ ] **الخصوصية / PII:** إيميل تنبيه الأدمن بقى مفيهوش بيانات العميل الشخصية
      (اسم/تليفون/ميزانية) — التفاصيل في الداشبورد بس؛ إيميل مزوّد الخدمة لوحده
      اللي فيه التليفون (محتاجه يتواصل). فكّر في **سياسة احتفاظ** (purge للـ leads
      القديمة بعد فترة) ووثّق اتفاقيات معالجة البيانات (DPA) مع Supabase وResend.
- [ ] **سجل التدقيق (Audit log):** العمليات الحسّاسة (حذف/تغيير حالة/تغيير
      صلاحيات/إنشاء حساب) بتتسجّل في جدول `AuditLog` وبتتقري من
      `GET /api/admin/audit-logs` (أدمن بس).
- [ ] **Sitemap (SEO):** الـ sitemap بقى ديناميكي من قاعدة البيانات على
      `https://<api-domain>/api/sitemap` (بيضيف الشركات/التصنيفات تلقائيًا من غير
      redeploy). حط `PUBLIC_SITE_URL` بدومين **الفرونت** عشان روابط الـ `loc` تطلع
      صح، واعمل submit للرابط ده في Google Search Console (أو ضيفه في `robots.txt`
      كـ `Sitemap:`). ملف [`app/public/sitemap.xml`](../../app/public/sitemap.xml)
      الثابت بقى **متجاوَز** — احذفه، أو اعمل rewrite في
      [`app/vercel.json`](../../app/vercel.json) من `/sitemap.xml` للـ API sitemap.
- [ ] `JWT_TTL` قصير في الإنتاج (الافتراضي دلوقتي `1d`)، و`JWT_SECRET` قوي وسري.
- [ ] **Security headers:** الهيدرز الأساسية (HSTS / nosniff / X-Frame-Options /
      Referrer-Policy / Permissions-Policy) مفعّلة تلقائيًا للباك إند
      ([`api/next.config.ts`](../../api/next.config.ts)) وللفرونت
      ([`app/vercel.json`](../../app/vercel.json)).
- [ ] **CSP (دفاع أساسي ضد XSS) — بقى متوصّل:**
      > ملاحظة: التوكن بقى في **httpOnly cookie** (مش localStorage)، فـ XSS مش
      > بيقدر يسرقه؛ الـ CSP فاضلة مهمة كدفاع عميق ضد حقن السكربتات عمومًا.

      الـ CSP اتحطّ **Report-Only** بالفعل في التنصيبتين:
      - VPS: [`deploy/Caddyfile`](../../deploy/Caddyfile) (بلوك الـ SPA).
      - Vercel: [`app/vercel.json`](../../app/vercel.json) — **غيّر `REPLACE-WITH-API-DOMAIN`**
        في `connect-src` لدومين الباك إند (على VPS مش محتاج — نفس الـ origin).

      والـ locale-init script اتنقل لملف خارجي
      ([`app/public/locale-init.js`](../../app/public/locale-init.js))، فـ `script-src`
      بقى `'self'` **من غير** `'unsafe-inline'` — يعني أي `<script>` محقون بيتمنع.

      **الخطوات:**
      1. انشر بالـ Report-Only، وافتح DevTools console وأنت بتتصفّح كل الصفحات
         (الرئيسية، تصنيف، شركة، فورم الطلب، `/admin`، `/provider`) وصلّح أي
         violation بيتبلّغ.
      2. بعد يومين/تلاتة هادية، فعّل الحجب: غيّر اسم الـ header من
         `Content-Security-Policy-Report-Only` لـ `Content-Security-Policy`.

      > `style-src` فيه `'unsafe-inline'` لأن React بيحط `style=""` inline (خطره
      > منخفض). `img-src` بيسمح بصور Supabase (`*.supabase.co`) + `data:`. سطر
      > `frame-src`/challenges.cloudflare.com محتاجه بس لو Turnstile مفعّل — شيله
      > غير كده.

---

## ما الذي يُدار من لوحة التحكم مقابل متغيرات البيئة

كل المحتوى التشغيلي والتسويقي يتدار من **`/admin`** بدون تعديل كود أو redeploy:
الشركات/التصنيفات/المشاريع/المعارض/التقييمات/الـ feedback/الـ leads/الحسابات،
**إعدادات المنصّة** (اسم الموقع، إيميل/تليفون الدعم، العنوان، روابط السوشيال،
قوائم المناطق والميزانيات، نصوص الـ hero بالعربي والإنجليزي)، **شعار/أيقونة
الموقع (logo/favicon)**، **قوالب إيميلات الإشعارات**، **صفحات الشروط والخصوصية**،
و**الـ SEO** (sitemap ديناميكي + meta لكل شركة/تصنيف).

أما الإعدادات التشغيلية (Infra) فتظل عبر **متغيّرات البيئة** (تتغيّر مرّة عند النشر،
مش محتاجة تعديل كود): `DATABASE_URL`/`DIRECT_URL`، `JWT_SECRET`/`JWT_TTL`،
`CORS_ALLOWED_ORIGINS`، `API_KEY`، `PUBLIC_SITE_URL`، Redis، Resend، CAPTCHA،
`SENTRY_DSN`. كلها موثّقة في [`api/.env.example`](../../api/.env.example).

---

## بديل: استضافة على VPS عادي (بدون Vercel)

- **الباك إند:** `npm ci && npx prisma generate && npm run build && npm start`
  (منفذ 3000) خلف Nginx/Caddy كـ reverse proxy، وشغّل خطوة 3 مرة واحدة.
- **الفرونت إند:** `npm ci && npm run build` ثم قدّم مجلد `dist/` كملفات ثابتة.
  لازم **SPA fallback** علشان الـ deep links، مثال Nginx:

  ```nginx
  location / {
    try_files $uri $uri/ /index.html;
  }
  ```

---

## ملخص أوامر سريع

```bash
# الباك إند (مرة واحدة بعد ربط قاعدة البيانات)
cd api && npx prisma migrate deploy && npm run seed
ADMIN_EMAIL=you@site.com ADMIN_PASSWORD='...' npm run create-admin

# تأكيد محلي إن كله بيـ build
cd api && npx tsc --noEmit
cd app && npm run build
```
